My program gets the message and sends the data but I could manage to send it back since I forgot to use pipe. So it needs arrangment and I realized it in last minute.
